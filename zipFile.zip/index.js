const { Client, Intents, MessageEmbed } = require('discord.js');
const fs = require('fs'); 
const https = require('https');

const client = new Client({ 
    intents: [
        Intents.FLAGS.GUILDS, 
        Intents.FLAGS.GUILD_MESSAGES, 
        Intents.FLAGS.MESSAGE_CONTENT
    ] 
});

// ==========================================
// CONFIGURATION DU BOT
// ==========================================
const SITE_URL = "https://nds-tournament.fr/classement/data.json";

// /!\ METS ICI L'ID DU SALON OÙ LE BOT DOIT ANNONCER LES MISES À JOUR /!\
const CHANNEL_ANNONCE_ID = "1471244255677648927"; 

// ==========================================
// SYSTÈME DE SYNCHRONISATION & ANNONCE
// ==========================================
function telechargerClassement() {
    const urlAntiCache = SITE_URL + "?t=" + Date.now();
    
    https.get(urlAntiCache, (reponse) => {
        let donnees = '';
        reponse.on('data', morceau => { donnees += morceau; });
        
        reponse.on('end', () => {
            try {
                const newJson = JSON.parse(donnees); 
                
                let oldJsonStr = "";
                if (fs.existsSync('./data.json')) {
                    const oldData = fs.readFileSync('./data.json', 'utf8');
                    oldJsonStr = JSON.stringify(JSON.parse(oldData));
                }
                
                const newJsonStr = JSON.stringify(newJson);

                if (oldJsonStr !== "" && oldJsonStr !== newJsonStr) {
                    const salonAnnonce = client.channels.cache.get(CHANNEL_ANNONCE_ID);
                    if (salonAnnonce) {
                        salonAnnonce.send("🚨 **MISE À JOUR DU CLASSEMENT NDS !** 🚨\nDe nouveaux résultats ont été saisis. Tapez `/top` pour voir les changements !");
                    }
                }

                fs.writeFileSync('./data.json', donnees); 
                console.log(`[${new Date().toLocaleTimeString()}] ✅ Classement synchronisé !`);
                
            } catch (e) {
                console.log(`[${new Date().toLocaleTimeString()}] ❌ Erreur : Le site n'a pas renvoyé un JSON valide.`);
            }
        });
    }).on('error', (erreur) => {
        console.log(`[${new Date().toLocaleTimeString()}] ❌ Impossible de se connecter au site :`, erreur.message);
    });
}

// ==========================================
// DÉMARRAGE DU BOT & CRÉATION DES COMMANDES
// ==========================================
client.once('ready', async () => {
    console.log(`✅ INCROYABLE ! Le bot ${client.user.tag} est en ligne !`);
    
    // Déclaration des Slash Commands avec AUTOCOMPLETE
    const slashCommands = [
        { name: 'ping', description: 'Vérifie si le bot est réveillé' },
        { name: 'top', description: 'Affiche le Top 5 du classement NDS' },
        { 
            name: 'stats', 
            description: 'Affiche les statistiques détaillées d\'un joueur',
            options: [{ 
                name: 'joueur', 
                type: 3, 
                description: 'Pseudo du joueur', 
                required: true,
                autocomplete: true // <-- On active l'auto-complétion ici !
            }]
        },
        { 
            name: 'vs', 
            description: 'Compare les stats de deux joueurs en face-à-face',
            options: [
                { name: 'joueur1', type: 3, description: 'Pseudo du premier joueur', required: true, autocomplete: true },
                { name: 'joueur2', type: 3, description: 'Pseudo du deuxième joueur', required: true, autocomplete: true }
            ]
        }
    ];

    // Envoi des commandes à Discord
    await client.application.commands.set(slashCommands);
    console.log("🛠️ Les Slash Commands ont été chargées !");

    // Lancement de la boucle de synchronisation (10 minutes)
    telechargerClassement();
    setInterval(telechargerClassement, 10 * 60 * 1000);
});

// ==========================================
// GESTION DES INTERACTIONS (AUTOCOMPLETE ET COMMANDES)
// ==========================================
client.on('interactionCreate', async (interaction) => {
    
    // --- 1. GESTION DE L'AUTO-COMPLÉTION (MENU DÉROULANT) ---
    if (interaction.isAutocomplete()) {
        try {
            // On lit les joueurs actuels
            const dataBrute = fs.readFileSync('./data.json', 'utf8');
            const players = JSON.parse(dataBrute);
            
            // On récupère ce que l'utilisateur est en train de taper
            const saisie = interaction.options.getFocused().toLowerCase();
            
            // On filtre les joueurs dont le nom commence par ce qui est tapé
            const choixFiltres = players.filter(p => p.name.toLowerCase().startsWith(saisie));
            
            // Discord limite l'affichage à 25 choix maximum
            const resultats = choixFiltres.slice(0, 25).map(p => ({
                name: p.name,
                value: p.name
            }));
            
            // On envoie les choix à Discord en direct
            await interaction.respond(resultats);
        } catch (error) {
            console.error(error);
            await interaction.respond([]);
        }
        return; // On arrête là pour l'auto-complétion
    }

    // --- 2. GESTION DES COMMANDES CLASSIQUES ---
    if (!interaction.isCommand()) return;

    // Commande : /ping
    if (interaction.commandName === 'ping') {
        await interaction.reply('Pong ! 🏓 La No Daddy Squad est dans la place !');
    }

    // Commande : /top
    if (interaction.commandName === 'top') {
        try {
            const dataBrute = fs.readFileSync('./data.json', 'utf8');
            const players = JSON.parse(dataBrute);

            players.sort((a, b) => b.points - a.points);
            const top5 = players.slice(0, 5);

            let reponse = "🏆 **CLASSEMENT GÉNÉRAL NDS - TOP 5** 🏆\n\n";
            top5.forEach((joueur, index) => {
                let medaille = "🏅";
                if (index === 0) medaille = "🥇";
                if (index === 1) medaille = "🥈";
                if (index === 2) medaille = "🥉";
                reponse += `${medaille} **#${index + 1} | ${joueur.name}** - ${joueur.points} pts *(Main: ${joueur.main || "?"})*\n`;
            });

            await interaction.reply(reponse);
        } catch (erreur) {
            await interaction.reply({ content: "Aïe, je n'arrive pas à lire le fichier data.json !", ephemeral: true });
        }
    }

    // Commande : /stats
    if (interaction.commandName === 'stats') {
        const pseudoRecherche = interaction.options.getString('joueur').toLowerCase();

        try {
            const dataBrute = fs.readFileSync('./data.json', 'utf8');
            const players = JSON.parse(dataBrute);
            const joueur = players.find(p => p.name.toLowerCase() === pseudoRecherche);

            if (!joueur) {
                return await interaction.reply({ content: `❌ Joueur **${interaction.options.getString('joueur')}** introuvable.`, ephemeral: true });
            }

            const embed = new MessageEmbed()
                .setColor('#ed1c24') 
                .setTitle(`👑 Profil : ${joueur.name}`)
                .setDescription(joueur.bio ? `*"${joueur.bio}"*` : "Prêt pour la bagarre.")
                .addFields(
                    { name: '🎮 Main', value: joueur.main || "Inconnu", inline: true },
                    { name: '🏆 Points', value: `${joueur.points || 0} pts`, inline: true },
                    { name: '⚔️ Tournois', value: `${joueur.participations || 0} joués`, inline: true },
                    { name: '🟢 Victoires', value: joueur.wins || "Aucune", inline: false },
                    { name: '🔴 Défaites', value: joueur.loses || "Aucune", inline: false }
                );

            if (joueur.mainUrl && joueur.mainUrl.startsWith('http')) embed.setThumbnail(joueur.mainUrl);

            await interaction.reply({ embeds: [embed] });
        } catch (erreur) {
            await interaction.reply({ content: "Aïe, problème de lecture des données.", ephemeral: true });
        }
    }

    // Commande : /vs (Face-à-Face)
    if (interaction.commandName === 'vs') {
        const pseudo1 = interaction.options.getString('joueur1').toLowerCase();
        const pseudo2 = interaction.options.getString('joueur2').toLowerCase();

        try {
            const dataBrute = fs.readFileSync('./data.json', 'utf8');
            const players = JSON.parse(dataBrute);
            
            const j1 = players.find(p => p.name.toLowerCase() === pseudo1);
            const j2 = players.find(p => p.name.toLowerCase() === pseudo2);

            if (!j1 || !j2) {
                return await interaction.reply({ content: `❌ Impossible de trouver l'un des deux joueurs dans la base de données.`, ephemeral: true });
            }

            const pts1 = parseInt(j1.points) || 0; const pts2 = parseInt(j2.points) || 0;
            const t1 = parseInt(j1.participations) || 0; const t2 = parseInt(j2.participations) || 0;

            const iconPts1 = pts1 >= pts2 ? (pts1 === pts2 ? '➖' : '🏆') : '❌';
            const iconPts2 = pts2 >= pts1 ? (pts2 === pts1 ? '➖' : '🏆') : '❌';
            
            const iconT1 = t1 >= t2 ? (t1 === t2 ? '➖' : '⚔️') : '❌';
            const iconT2 = t2 >= t1 ? (t2 === t1 ? '➖' : '⚔️') : '❌';

            const embed = new MessageEmbed()
                .setColor('#ffd700') 
                .setTitle(`🥊 FACE-À-FACE : ${j1.name} VS ${j2.name}`)
                .setDescription(`La comparaison des titans de la No Daddy Squad !`)
                .addFields(
                    { name: '🎮 Personnages (Main)', value: `**${j1.name}** : ${j1.main || "?"}\n**${j2.name}** : ${j2.main || "?"}`, inline: false },
                    { name: '🏆 Score Global', value: `${iconPts1} **${j1.name}** : ${pts1} pts\n${iconPts2} **${j2.name}** : ${pts2} pts`, inline: false },
                    { name: '⚔️ Tournois Joués', value: `${iconT1} **${j1.name}** : ${t1}\n${iconT2} **${j2.name}** : ${t2}`, inline: false }
                )
                .setFooter({ text: "NDS Power Ranking" });

            await interaction.reply({ embeds: [embed] });
            
        } catch (erreur) {
            await interaction.reply({ content: "Aïe, problème de lecture des données.", ephemeral: true });
        }
    }
});

// Ton mot de passe secret
const TOKEN = "MTQ3OTMyOTcxMjcxMDA5MDkxMw.GemmSX.6wZ13jgzGD1RXsXu_gCFKa0oIh5lF1K9s6hynA";

client.login(TOKEN);